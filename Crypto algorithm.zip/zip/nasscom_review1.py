import math
import sympy
import time
import random
t0=time.time()
count=0;m=[]
o=int(input("Enter bit length for p and q generation :"))
while(count<2):
    n1=random.getrandbits(o)
    if(sympy.isprime(n1)):
        m.append(n1)
        count+=1
p=m[0];q=m[1]
print("p and q generated are :",p," ",q)
n=p*q
pi=(p-1)*(q-1)
for i in range(2,pi):
    if(sympy.isprime(i)):
        if(i!=p and i!=q):
            if(math.gcd(i,pi)==1):
                e=i
def modInverse(a, m) : 
    a = a % m; 
    for x in range(1, m) : 
        if ((a * x) % m == 1) : 
            return x 
    return 1
d=modInverse(e,pi);x1=[];y1=[]
r=int(input("Enter a random number :"))
count=0
for i in range(1,500):
    for j in range(1,500):
        if(pow(i,4)*j-r*pow(j,3)==1):
            count+=1
            x1.append(i);y1.append(j)
if(count==0):
    print("no answers select another random number")
print("possible values of x and y are :",x1,y1)
x=x1[0];y=y1[0]
print("x y :",x,y)
if(pow(x,4)-r*pow(y,3)==1):
    print("TESTCASE-1: Testcase for x and y is successful")
else:
    print("TESTCASE-1: Testcase for x and y is not successful")
al1=((x+e)*(x+e)*(x+e)*(x+e)*(y+pi))%pi+(-(y+pi)*(y+pi)*(y+pi)*r)%pi
ver=(al1-(e*e*e*e*y)%pi-(4*x*y*e*e*e)%pi-(4*x*x*x*e*y)%pi-(6*x*x*e*e*y)%pi)%pi
print("e is ",e," pi(n) is ",pi," verification alpha is",ver);print("")
if(ver==1):
    print("TESTCASE-2: Testcase for alpha is successful")
else:
    print("TESTCASE-2: Testcase for alpha is unsuccessful")
print("Private Keys are :- e:",e," N:",n)
print("Public keys are :-(e^3y+4x^3y+6x^2ey+4xye*2)%pi(n) :",((e*e*e*y)+(4*x*x*x*y)+(6*x*x*e*y)+(4*x*y*e*e))%pi," alpha:",al1," N:",n);print("")
print("Encryption :")
m=int(input("Enter message :"))
te1=time.time()
ct1=pow(m,al1)%n
ct2=pow(m,((e*e*e*y)+(4*x*x*x*y)+(6*x*x*e*y)+(4*x*y*e*e))%pi)%n
te2=time.time()
print("CT1 and CT2 :",ct1,",",ct2)
print("Time taken for Encryption :",round(te2-te1),"sec");print("")
print("Decryption :")
td1=time.time()
dt=(ct1*pow(ct2,(-e)%pi))%n
td2=time.time()
print("Decrypted text :",dt%n)
print("Time taken for Decryption :",round(td2-td1),"sec");print("")
if(dt==m):
    print("Technique Successful")
else:
    print("Technique Failed")
t1=time.time()
print("Total time taken for process :",round(t1-t0,3)," sec time")
